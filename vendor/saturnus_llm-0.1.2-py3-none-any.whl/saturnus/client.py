from collections.abc import AsyncGenerator, AsyncIterator
from contextlib import asynccontextmanager
from types import TracebackType
from typing import Any, Self

import httpx

from ._json import decode_json
from .compatibility import Compatibility
from .errors import APIError, ResponseError, TransportError, ValidationError
from .responses import ChatResponse, ChatStreamResponse
from .streaming import iter_chunks
from .validation import (
    validate_client_config,
    validate_headers,
    validate_json,
    validate_request,
)


class ChatClient:
    """An asynchronous client for Chat Completions APIs."""

    def __init__(
        self,
        *,
        base_url: str,
        endpoint_path: str = "chat/completions",
        api_key: str | None = None,
        auth_headers: dict[str, str] | None = None,
        timeout: float = 30.0,
        compatibility: Compatibility | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        validate_client_config(
            base_url=base_url,
            endpoint_path=endpoint_path,
            api_key=api_key,
            timeout=timeout,
        )

        if api_key is not None and auth_headers is not None:
            raise ValidationError(
                "api_key and auth_headers cannot be provided together."
            )

        headers = validate_headers(
            auth_headers,
            allow_authorization=True,
        )
        if api_key is not None:
            headers["Authorization"] = f"Bearer {api_key}"

        if compatibility is not None and not isinstance(compatibility, Compatibility):
            raise ValidationError(
                "compatibility must be a Compatibility instance or None."
            )

        if transport is not None and not isinstance(
            transport, httpx.AsyncBaseTransport
        ):
            raise ValidationError(
                "transport must be an AsyncBaseTransport instance or None."
            )

        url = httpx.URL(base_url)
        endpoint = httpx.URL(endpoint_path)
        path, separator, query = url.raw_path.partition(b"?")
        self._endpoint_url = url.copy_with(
            raw_path=(path.rstrip(b"/") + b"/" + endpoint.raw_path + separator + query)
        )

        self._compatibility = compatibility
        self._auth_header_names = {name.lower() for name in headers}
        self._http = httpx.AsyncClient(
            headers=headers,
            timeout=timeout,
            transport=transport,
        )

    async def __aenter__(self) -> Self:
        await self._http.__aenter__()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        await self._http.__aexit__(exc_type, exc, traceback)

    async def aclose(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.aclose()

    def _prepare_request(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        stream: bool = False,
    ) -> tuple[dict[str, Any], dict[str, str]]:
        validate_request(model=model, messages=messages)

        body: dict[str, Any] = {
            "model": model,
            "messages": messages,
        }
        if stream:
            body["stream"] = True

        if extra_body is not None:
            if not isinstance(extra_body, dict):
                raise ValidationError("extra_body must be an object.")

            conflicts = {"model", "messages", "stream"}.intersection(extra_body)
            if conflicts:
                names = ", ".join(sorted(conflicts))
                raise ValidationError(
                    f"extra_body conflicts with reserved fields: {names}."
                )
            body.update(extra_body)

        if self._compatibility is not None:
            body = self._compatibility.apply(body)

        validate_json(body)
        headers = validate_headers(
            extra_headers,
            protected_names=self._auth_header_names,
        )
        return body, headers

    async def create_with_response(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> ChatResponse:
        """Send a non-streaming request and retain its HTTP response."""

        body, headers = self._prepare_request(
            model=model,
            messages=messages,
            extra_body=extra_body,
            extra_headers=extra_headers,
        )

        try:
            response = await self._http.post(
                self._endpoint_url,
                json=body,
                headers=headers,
            )
        except httpx.RequestError as exc:
            raise TransportError("The HTTP request could not be completed.") from exc

        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise APIError(
                f"The server returned HTTP {response.status_code}.",
                response=response,
            ) from exc

        try:
            data = decode_json(response.content)
        except ValueError as exc:
            raise ResponseError(
                "The server returned invalid JSON.",
                response=response,
            ) from exc

        if not isinstance(data, dict):
            raise ResponseError(
                "Expected a JSON object response.",
                response=response,
            )

        return ChatResponse(data=data, response=response)

    @asynccontextmanager
    async def stream_with_response(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> AsyncGenerator[ChatStreamResponse, None]:
        """Open a stream and retain its HTTP response."""
        body, headers = self._prepare_request(
            model=model,
            messages=messages,
            extra_body=extra_body,
            extra_headers=extra_headers,
            stream=True,
        )

        request = self._http.build_request(
            "POST",
            self._endpoint_url,
            json=body,
            headers=headers,
        )

        try:
            response = await self._http.send(request, stream=True)
        except httpx.RequestError as exc:
            raise TransportError("The HTTP request could not be completed.") from exc

        try:
            try:
                response.raise_for_status()
            except httpx.HTTPStatusError as exc:
                try:
                    await response.aread()
                except httpx.RequestError as read_exc:
                    raise TransportError(
                        "The server error response could not be read."
                    ) from read_exc

                raise APIError(
                    f"The server returned HTTP {response.status_code}.",
                    response=response,
                ) from exc

            content_type = response.headers.get("content-type", "")
            media_type = content_type.partition(";")[0].strip().lower()
            if media_type != "text/event-stream":
                try:
                    await response.aread()
                except httpx.RequestError as exc:
                    raise TransportError("The response could not be read.") from exc

                raise ResponseError(
                    "Expected a text/event-stream response.",
                    response=response,
                )

            chunks = iter_chunks(response)
            try:
                yield ChatStreamResponse(chunks=chunks, response=response)
            finally:
                await chunks.aclose()
        finally:
            await response.aclose()

    async def create(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Send one non-streaming Chat Completions request."""
        result = await self.create_with_response(
            model=model,
            messages=messages,
            extra_body=extra_body,
            extra_headers=extra_headers,
        )
        return result.data

    @asynccontextmanager
    async def stream(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> AsyncGenerator[AsyncIterator[dict[str, Any]], None]:
        """Open a streaming request and yield its JSON chunks."""
        async with self.stream_with_response(
            model=model,
            messages=messages,
            extra_body=extra_body,
            extra_headers=extra_headers,
        ) as result:
            yield result.chunks
