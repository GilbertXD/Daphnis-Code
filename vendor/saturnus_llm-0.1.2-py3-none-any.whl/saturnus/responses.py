from collections.abc import AsyncIterator
from copy import deepcopy
from dataclasses import dataclass
from typing import Any

import httpx

from .errors import ValidationError
from .validation import validate_json, validate_message


@dataclass(frozen=True)
class ChatResponse:
    """A JSON result and its original HTTP response."""

    data: dict[str, Any]
    response: httpx.Response


@dataclass(frozen=True)
class ChatStreamResponse:
    """A chunk iterator and its live HTTP response."""

    chunks: AsyncIterator[dict[str, Any]]
    response: httpx.Response


def _get_choice_field(
    response: dict[str, Any],
    *,
    choice_index: int,
    choices_field: str,
    index_field: str,
    field: str,
) -> tuple[Any, str]:
    if not isinstance(response, dict):
        raise ValidationError("Response must be an object.")
    if (
        isinstance(choice_index, bool)
        or not isinstance(choice_index, int)
        or choice_index < 0
    ):
        raise ValidationError("choice_index must be a non-negative integer.")
    for name in (choices_field, index_field, field):
        if not isinstance(name, str) or not name.strip():
            raise ValidationError("Response field names must be non-empty strings.")

    choices = response.get(choices_field)
    if not isinstance(choices, list):
        raise ValidationError(f"response.{choices_field} must be a list.")

    indices: set[int] = set()
    selected = None
    for position, choice in enumerate(choices):
        path = f"response.{choices_field}[{position}]"
        if not isinstance(choice, dict):
            raise ValidationError(f"{path} must be an object.")
        index = choice.get(index_field)
        if isinstance(index, bool) or not isinstance(index, int) or index < 0:
            raise ValidationError(
                f"{path}.{index_field} must be a non-negative integer."
            )
        if index in indices:
            raise ValidationError(f"Duplicate choice index in response: {index}.")
        indices.add(index)
        if index == choice_index:
            selected = choice, path

    if selected is None:
        raise ValidationError(f"Response has no choice with index {choice_index}.")
    choice, path = selected
    if field not in choice:
        raise ValidationError(f"{path}.{field} is required.")
    return choice[field], f"{path}.{field}"


def get_message(
    response: dict[str, Any],
    *,
    choice_index: int = 0,
    choices_field: str = "choices",
    index_field: str = "index",
    message_field: str = "message",
) -> dict[str, Any]:
    """Return an independent copy of the message for the given choice index."""
    message, path = _get_choice_field(
        response,
        choice_index=choice_index,
        choices_field=choices_field,
        index_field=index_field,
        field=message_field,
    )
    validate_message(message, path=path, require_role=False)
    try:
        validate_json(message)
    except ValidationError as exc:
        raise ValidationError(f"{path} must be valid JSON.") from exc
    return deepcopy(message)


def get_finish_reason(
    response: dict[str, Any],
    *,
    choice_index: int = 0,
    choices_field: str = "choices",
    index_field: str = "index",
    finish_reason_field: str = "finish_reason",
) -> str | None:
    """Return the choice's finish reason, including an explicitly null value."""
    reason, path = _get_choice_field(
        response,
        choice_index=choice_index,
        choices_field=choices_field,
        index_field=index_field,
        field=finish_reason_field,
    )
    if reason is not None and (not isinstance(reason, str) or not reason.strip()):
        raise ValidationError(f"{path} must be a non-empty string or null.")
    return reason
