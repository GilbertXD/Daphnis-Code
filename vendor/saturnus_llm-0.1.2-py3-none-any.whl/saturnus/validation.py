import json
import re
from math import isfinite
from typing import Any

import httpx

from .errors import ValidationError


def validate_client_config(
    *,
    base_url: str,
    endpoint_path: str,
    api_key: str | None,
    timeout: float,
) -> None:
    """Validate connection settings before creating the HTTP client."""
    if not isinstance(base_url, str) or not base_url:
        raise ValidationError("base_url must be a non-empty string.")

    if any(char.isspace() or ord(char) < 32 or ord(char) == 127 for char in base_url):
        raise ValidationError("base_url contains whitespace or control characters.")

    try:
        url = httpx.URL(base_url)
    except (httpx.InvalidURL, UnicodeError) as exc:
        raise ValidationError("base_url must be a valid URL.") from exc

    if url.scheme not in {"http", "https"} or not url.host:
        raise ValidationError("base_url must be an absolute HTTP or HTTPS URL.")

    if "#" in base_url:
        raise ValidationError("base_url must not contain a fragment.")

    if url.userinfo:
        raise ValidationError("base_url must not contain authentication credentials.")

    if not isinstance(endpoint_path, str) or not endpoint_path:
        raise ValidationError("endpoint_path must be a non-empty string.")

    if endpoint_path.startswith("/") or "?" in endpoint_path or "#" in endpoint_path:
        raise ValidationError(
            "endpoint_path must be relative and must not contain a query or fragment."
        )

    if any(
        char.isspace() or ord(char) < 32 or ord(char) == 127 for char in endpoint_path
    ):
        raise ValidationError(
            "endpoint_path contains whitespace or control characters."
        )

    if any(segment in {".", ".."} for segment in endpoint_path.split("/")):
        raise ValidationError("endpoint_path must not contain dot segments.")

    try:
        endpoint = httpx.URL(endpoint_path)
    except (httpx.InvalidURL, UnicodeError) as exc:
        raise ValidationError("endpoint_path must be a valid relative path.") from exc

    if endpoint.scheme or endpoint.host:
        raise ValidationError("endpoint_path must be a relative path.")

    if api_key is not None and (
        not isinstance(api_key, str)
        or not api_key
        or any(ord(char) < 33 or ord(char) > 126 for char in api_key)
    ):
        raise ValidationError(
            "api_key must be a non-empty ASCII string without whitespace."
        )

    if isinstance(timeout, bool) or not isinstance(timeout, (int, float)):
        raise ValidationError("timeout must be a finite positive number.")

    try:
        valid_timeout = isfinite(timeout) and timeout > 0
    except OverflowError as exc:
        raise ValidationError("timeout must be a finite positive number.") from exc

    if not valid_timeout:
        raise ValidationError("timeout must be a finite positive number.")


def validate_request(
    *,
    model: str,
    messages: list[dict[str, Any]],
) -> None:
    if not isinstance(model, str) or not model.strip():
        raise ValidationError("model must be a non-empty string.")

    if not isinstance(messages, list) or not messages:
        raise ValidationError("messages must be a non-empty list.")

    for index, message in enumerate(messages):
        validate_message(message, path=f"messages[{index}]")


def validate_message(
    message: dict[str, Any], *, path: str = "message", require_role: bool = True
) -> None:
    """Validate the basic structure without restricting extension fields."""
    if not isinstance(message, dict):
        raise ValidationError(f"{path} must be an object.")

    role = message.get("role")
    if (require_role or "role" in message) and (
        not isinstance(role, str) or not role.strip()
    ):
        raise ValidationError(f"{path}.role must be a non-empty string.")

    content = message.get("content")
    if content is not None and not isinstance(content, (str, list)):
        raise ValidationError(f"{path}.content must be a string, list, or null.")


def validate_json(value: Any) -> None:
    """Check JSON serializability without implicit type conversions."""
    try:
        json.dumps(value, allow_nan=False)
        _check_json_structure(value)
    except (TypeError, ValueError, OverflowError, RecursionError) as exc:
        raise ValidationError("Request data must be valid JSON.") from exc


def _check_json_structure(value: Any) -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise ValidationError("JSON object keys must be strings.")
            _check_json_structure(item)

    elif isinstance(value, list):
        for item in value:
            _check_json_structure(item)

    elif isinstance(value, tuple):
        raise ValidationError("JSON arrays must use lists, not tuples.")


def validate_headers(
    headers: dict[str, str] | None,
    *,
    allow_authorization: bool = False,
    protected_names: set[str] | None = None,
) -> dict[str, str]:
    """Validate request headers and return a separate dictionary."""
    if headers is None:
        return {}

    if not isinstance(headers, dict):
        raise ValidationError("Headers must be an object.")

    reserved = {
        "content-type",
        "content-length",
        "transfer-encoding",
        "host",
    }
    if not allow_authorization:
        reserved.add("authorization")
    if protected_names:
        reserved.update(name.lower() for name in protected_names)
    seen = set()

    for name, value in headers.items():
        if (
            not isinstance(name, str)
            or re.fullmatch(r"[-!#$%&'*+.^_`|~0-9A-Za-z]+", name) is None
        ):
            raise ValidationError("Header names must be valid ASCII tokens.")

        if not isinstance(value, str):
            raise ValidationError(f"Header {name!r} must have a string value.")

        normalized = name.lower()
        if normalized in reserved:
            raise ValidationError(f"Header {name!r} is controlled by ChatClient.")

        if normalized in seen:
            raise ValidationError(f"Duplicate header name: {name!r}.")
        seen.add(normalized)

        if value != value.strip(" \t") or any(
            (ord(char) < 32 and char != "\t") or ord(char) > 126 for char in value
        ):
            raise ValidationError(
                f"Header {name!r} contains invalid characters or whitespace."
            )

    return dict(headers)
