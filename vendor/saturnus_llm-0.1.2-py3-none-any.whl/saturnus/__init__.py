"""Lightweight LLM connectivity and protocol compatibility tools."""

from .aggregation import ResponseAccumulator
from .client import ChatClient
from .compatibility import Compatibility
from .errors import (
    APIError,
    ResponseError,
    SaturnusError,
    ToolCallValidationError,
    ToolExecutionError,
    TransportError,
    ValidationError,
)
from .messages import Messages
from .responses import ChatResponse, ChatStreamResponse, get_finish_reason, get_message
from .tools import ToolRegistry, ToolResult

__all__ = [
    "APIError",
    "ChatClient",
    "ChatResponse",
    "ChatStreamResponse",
    "Compatibility",
    "Messages",
    "ResponseAccumulator",
    "ResponseError",
    "SaturnusError",
    "ToolCallValidationError",
    "ToolExecutionError",
    "ToolRegistry",
    "ToolResult",
    "TransportError",
    "ValidationError",
    "get_finish_reason",
    "get_message",
]
