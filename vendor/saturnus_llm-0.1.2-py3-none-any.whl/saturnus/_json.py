import json
from typing import Any, NoReturn


def _reject_constant(value: str) -> NoReturn:
    raise ValueError(f"Non-standard JSON constant: {value}.")


def decode_json(data: str | bytes) -> Any:
    """Decode JSON while rejecting non-standard numeric constants."""
    return json.loads(data, parse_constant=_reject_constant)
